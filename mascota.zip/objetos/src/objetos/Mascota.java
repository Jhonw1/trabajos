package objetos;

import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;

public class Mascota {
	private ArrayList<String> listaMascotas;
	private HashMap<String, ArrayList<String>> mapaMascotas = new HashMap<>();
	private String identificacion;
	private String nombre;
	private String especie;
	private int edad;

	public Mascota(ArrayList<String> listaMascotas, String identificacion, String nombre, String especie, int edad) {
		this.listaMascotas = listaMascotas;
		this.identificacion = identificacion;
		this.nombre = nombre;
		this.especie = especie;
		this.edad = edad;

	}

	public ArrayList<String> getlistaMascotas() {
		return listaMascotas;
	}

	public void setlistaMascotas(ArrayList<String> listaMascotas) {
		this.listaMascotas = listaMascotas;
	}

	public HashMap<String, ArrayList<String>> getmapaMascotas() {
		return mapaMascotas;
	}

	public void setmapaMascotas(HashMap<String, ArrayList<String>> mapaMascotas) {
		this.mapaMascotas = mapaMascotas;
	}

	public String getidentificacion() {
		return identificacion;
	}

	public void setidentificacion(String identificacion) {
		this.identificacion = identificacion;
	}

	public String getnombre() {
		return nombre;
	}

	public void setnombre(String nombre) {
		this.nombre = nombre;
	}

	public String getespecie() {
		return especie;
	}

	public void setespecie(String especie) {
		this.especie = especie;
	}

	public int getedad() {
		return edad;
	}

	public void setedad(int edad) {
		this.edad = edad;
	}

	public void mostrarInformacion() {
		System.out.println("Nombre: " + nombre);
		System.out.println("Especie: " + especie);
		System.out.println("Edad: " + edad + " años");
	}

	public void hacerSonido() {
		if (especie.equalsIgnoreCase("perro")) {
			System.out.println("¡Guau guau!");
		} else if (especie.equalsIgnoreCase("gato")) {
			System.out.println("¡Miau miau!");
		} else {
			System.out.println("La mascota no hace sonidos conocidos.");
		}
	}

	public void atacar() {
		if (especie.equals("perro")) {
			System.out.println("el perro mordio");
		} else if (especie.equals("gato")) {
			System.out.println("el gato aruño");
		} else if (especie.equals("caballo")) {
			System.out.println("el caballo pateo");
		} else {
			System.out.println("no reconozco la mascota");
		}
	}

	public void comer() {
		if (especie.equals("perro")) {
			System.out.println("el perro comio croquetas");
		} else if (especie.equals("gato")) {
			System.out.println("el gato comio pescado");
		} else if (especie.equals("caballo")) {
			System.out.println("el caballo comio pasto");
		} else {
			System.out.println("no reconozco la mascota");
		}
	}

	public void registrarMascotas() {
		String identificacionMascota;
		String nombreMascota;
		String especieMascota;
		String edadMascota;
		String otraMascota = "";
		do {
			listaMascotas = new ArrayList<String>();
			identificacionMascota = JOptionPane.showInputDialog("ingrese la identificacion de la mascota");
			nombreMascota = JOptionPane.showInputDialog("ingrese el nombre de la mascota");
			especieMascota = JOptionPane.showInputDialog("ingrese la especie de la mascota");
			edadMascota = JOptionPane.showInputDialog("ingrese la edad de la mascota");
			listaMascotas.add(identificacionMascota);
			listaMascotas.add(nombreMascota);
			listaMascotas.add(especieMascota);
			listaMascotas.add(edadMascota);
			mapaMascotas.put(listaMascotas.get(0), listaMascotas);

			otraMascota = JOptionPane.showInputDialog("desea ingresar otra mascota?s/n");

		} while (otraMascota.equals("s"));
	}

	public void buscarMascota() {
		String buscar = JOptionPane.showInputDialog("ingrese la identificacion de la mascota");
		for (int i = 0; i < mapaMascotas.size(); i++) {
			if (mapaMascotas.get(i).equals(buscar)) {
				System.out.println(listaMascotas);
			}

		}

	}

	public void mostrarTodo() {
		for (String identificacion : mapaMascotas.keySet()) {
			System.out.println(mapaMascotas.get(identificacion));
		}
	}

	public void actualizar() {
		String mascotaActualizar = JOptionPane
				.showInputDialog("ingrese la identificacion de la mascota que desea actualizar");
		String actualizarDato;
		String nuevoDato;
		for (int i = 0; i < mapaMascotas.size(); i++) {
			if (mapaMascotas.keySet().equals(mascotaActualizar)) {
				actualizarDato = JOptionPane.showInputDialog("desea actualizar nombre, especie o edad?");
				if (actualizarDato.equals("nombre")) {
					nuevoDato = JOptionPane.showInputDialog("ingrese el nuevo nombre");
					listaMascotas.set(1, nuevoDato);
				} else if (actualizarDato.equals("especie")) {
					nuevoDato = JOptionPane.showInputDialog("ingrese la nueva especie");
					listaMascotas.set(2, nuevoDato);
				} else if (actualizarDato.equals("edad")) {
					nuevoDato = JOptionPane.showInputDialog("ingrese la nueva edad");
					listaMascotas.set(3, nuevoDato);
				} else {
					System.out.println("no existe esa opcion");
				}

			}
		}

	}

}
