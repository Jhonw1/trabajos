package dosClases;

public class Aplication {
	public static void main(String[] args) {
		Entidad rectangulo;
		rectangulo=new Entidad();
		rectangulo.ingresarDatos();
		rectangulo.calcularArea();
	}
}
