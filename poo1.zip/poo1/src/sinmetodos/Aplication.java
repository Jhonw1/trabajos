package sinmetodos;

import javax.swing.*;

public class Aplication {

	public class aplicacion {
		public static void main(String arg[]) {

			String cadena;
			double ladoA;
			double ladoB;
			double resultado;

			cadena = JOptionPane.showInputDialog(null, "Ingrese la longitud del lado A: ");
			ladoA = Double.parseDouble(cadena);

			cadena = JOptionPane.showInputDialog(null, "Ingrese la longitud del lado B: ");
			ladoB = Double.parseDouble(cadena);

			resultado = ladoA * ladoB;
			JOptionPane.showMessageDialog(null, "El resultado es: " + resultado);
		}

	}
}
