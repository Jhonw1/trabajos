package poo2;

import javax.swing.JOptionPane;

public class Flecha {
	int longitud;
	String color;

	public Flecha() {
		longitud = 18;
		color = "negro";
	}

	public Flecha(int longitud, String color) {
		this.longitud = longitud;
		this.color = color;
	}
	public void longitudFlecha() {
		longitud=Integer.parseInt(JOptionPane.showInputDialog("ingrese la longitud de la flecha"));
	}

	public void construirFlecha() {
		for (int i = 0; i < longitud; i++) {
			imprime("-");
		}
		imprime(">");
	}

	public void imprimirEspacio() {
		System.out.println();

	}

	private void imprime(String simbolo) {
		if (color.equals("negro")) {
			System.out.println(simbolo);

		} else {

			System.err.println(simbolo);
		}
	}

}
